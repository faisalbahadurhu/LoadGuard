# LoadGuard-JMeter v1.2 Source Code

This Eclipse-friendly Java project contains the source code for the LoadGuard-JMeter v1.2 plugin.

## Components

- `ElasticLoadTimerGui`: JMeter GUI class for `Thread Group -> Add -> Timer -> LoadGuard Elastic Timer`.
- `ElasticLoadTimer`: Runtime JMeter Timer. It reads the current target RPS and converts it into per-thread request delay.
- `ElasticMetricsListenerGui`: JMeter GUI class for `Thread Group -> Add -> Listener -> LoadGuard Metrics Listener`.
- `ElasticMetricsListener`: Runtime JMeter listener. It receives completed samples, computes interval metrics, and asks the controller for the next action.
- `LoadGuardController`: Shared closed-loop controller. It applies warm-up, SAFE/HOLD/VIOLATION zones, and updates target RPS.
- `LoadGuardCsvWriter`: Writes interval-level controller decisions to CSV.
- `SampleWindow`: Collects response times and errors for one monitoring interval.

## Eclipse setup

1. Open Eclipse.
2. Use `File -> Import -> Existing Projects into Workspace`.
3. Select this folder.
4. Add JMeter libraries to the project build path:
   - Right click project -> Build Path -> Configure Build Path
   - Libraries -> Add External JARs
   - Select all required JARs from `JMETER_HOME/lib` and `JMETER_HOME/lib/ext`.
5. Use JDK 17.

## Building without Maven

Maven is not required. Export from Eclipse:

`Right click project -> Export -> Java -> JAR file`

Export compiled classes and the `META-INF/MANIFEST.MF` file.

Place the resulting JAR in:

`JMETER_HOME/lib/ext/`

Then restart JMeter.

## Suggested JMeter settings

Thread Group:
- Threads: 20
- Ramp-up: 5 seconds
- Duration: 120 seconds or Loop Count: 500

LoadGuard Elastic Timer:
- Initial target RPS: 5
- Minimum RPS: 1
- Maximum RPS: 50

LoadGuard Metrics Listener:
- Control interval seconds: 5
- Warm-up seconds: 15
- p95 response-time SLO ms: 100
- Error-rate SLO percent: 5
- Increase percent: 20
- Decrease percent: 30
- HOLD margin percent: 30
- CSV path: e.g. `C:\Users\DELL\Desktop\loadguard-v12.csv`

## Notes

This version is a closed-loop SLO-aware rule-guided controller. It does not contain the ML module yet.
