package org.loadguard.elastic;

import java.io.Serializable;

import org.apache.jmeter.engine.event.LoopIterationEvent;
import org.apache.jmeter.engine.event.LoopIterationListener;
import org.apache.jmeter.engine.event.TestStateListener;
import org.apache.jmeter.threads.JMeterContextService;
import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jmeter.timers.Timer;

/**
 * JMeter Timer that applies request pacing based on the current target RPS.
 */
public class ElasticLoadTimer extends AbstractTestElement
        implements Timer, TestStateListener, LoopIterationListener, Serializable {

    private static final long serialVersionUID = 1L;

    public static final String INITIAL_RPS = "LoadGuardElasticTimer.initialRps";
    public static final String MIN_RPS = "LoadGuardElasticTimer.minRps";
    public static final String MAX_RPS = "LoadGuardElasticTimer.maxRps";
    public static final String VERBOSE = "LoadGuardElasticTimer.verbose";

    @Override
    public long delay() {
        LoadGuardController controller = LoadGuardController.getInstance();

        int activeThreads = Math.max(1, JMeterContextService.getNumberOfThreads());
        double targetRps = Math.max(0.001, controller.getTargetRps());

        long delayMs = Math.round((activeThreads * 1000.0) / targetRps);
        delayMs = Math.max(0L, delayMs);

        controller.setTimerDelayMs(delayMs);
        return delayMs;
    }

    @Override
    public void testStarted() {
        configureController();
        LoadGuardController.getInstance().testStarted();
    }

    @Override
    public void testStarted(String host) {
        testStarted();
    }

    @Override
    public void testEnded() {
        LoadGuardController.getInstance().testEnded();
    }

    @Override
    public void testEnded(String host) {
        testEnded();
    }

    @Override
    public void iterationStart(LoopIterationEvent iterEvent) {
        // No per-iteration state is needed in v1.2.
    }

    private void configureController() {
        double initialRps = getPropertyAsDouble(INITIAL_RPS, 5.0);
        double minRps = getPropertyAsDouble(MIN_RPS, 1.0);
        double maxRps = getPropertyAsDouble(MAX_RPS, 50.0);
        boolean verbose = getPropertyAsBoolean(VERBOSE, false);

        LoadGuardController.getInstance().configureTimer(initialRps, minRps, maxRps, verbose);
    }
}
