package org.loadguard.elastic;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.timers.gui.AbstractTimerGui;

/**
 * GUI component for LoadGuard Elastic Timer.
 */
public class ElasticLoadTimerGui extends AbstractTimerGui {

    private static final long serialVersionUID = 1L;

    private JTextField initialRpsField;
    private JTextField minRpsField;
    private JTextField maxRpsField;
    private JCheckBox verboseCheckBox;

    public ElasticLoadTimerGui() {
        init();
    }

    @Override
    public String getStaticLabel() {
        return "LoadGuard Elastic Timer";
    }

    @Override
    public String getLabelResource() {
        return null;
    }

    @Override
    public TestElement createTestElement() {
        ElasticLoadTimer timer = new ElasticLoadTimer();
        modifyTestElement(timer);
        return timer;
    }

    @Override
    public void modifyTestElement(TestElement element) {
        configureTestElement(element);
        element.setProperty(ElasticLoadTimer.INITIAL_RPS, parseDouble(initialRpsField.getText(), 5.0));
        element.setProperty(ElasticLoadTimer.MIN_RPS, parseDouble(minRpsField.getText(), 1.0));
        element.setProperty(ElasticLoadTimer.MAX_RPS, parseDouble(maxRpsField.getText(), 50.0));
        element.setProperty(ElasticLoadTimer.VERBOSE, verboseCheckBox.isSelected());
    }

    @Override
    public void configure(TestElement element) {
        super.configure(element);
        initialRpsField.setText(String.valueOf(element.getPropertyAsDouble(ElasticLoadTimer.INITIAL_RPS, 5.0)));
        minRpsField.setText(String.valueOf(element.getPropertyAsDouble(ElasticLoadTimer.MIN_RPS, 1.0)));
        maxRpsField.setText(String.valueOf(element.getPropertyAsDouble(ElasticLoadTimer.MAX_RPS, 50.0)));
        verboseCheckBox.setSelected(element.getPropertyAsBoolean(ElasticLoadTimer.VERBOSE, false));
    }

    @Override
    public void clearGui() {
        super.clearGui();
        initialRpsField.setText("5");
        minRpsField.setText("1");
        maxRpsField.setText("50");
        verboseCheckBox.setSelected(false);
    }

    private void init() {
        setLayout(new BorderLayout(0, 5));
        setBorder(makeBorder());

        add(getNamePanel(), BorderLayout.NORTH);

        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));

        initialRpsField = new JTextField("5");
        minRpsField = new JTextField("1");
        maxRpsField = new JTextField("50");
        verboseCheckBox = new JCheckBox("Verbose logging", false);

        panel.add(new JLabel("Initial target RPS"));
        panel.add(initialRpsField);
        panel.add(new JLabel("Minimum RPS"));
        panel.add(minRpsField);
        panel.add(new JLabel("Maximum RPS"));
        panel.add(maxRpsField);
        panel.add(new JLabel("Verbose logging"));
        panel.add(verboseCheckBox);

        add(panel, BorderLayout.CENTER);
    }

    private static double parseDouble(String text, double defaultValue) {
        try {
            return Double.parseDouble(text.trim());
        } catch (Exception ex) {
            return defaultValue;
        }
    }
}
