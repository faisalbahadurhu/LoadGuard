package org.loadguard.elastic;

import java.io.Serializable;

import org.apache.jmeter.engine.event.TestStateListener;
import org.apache.jmeter.samplers.SampleEvent;
import org.apache.jmeter.samplers.SampleListener;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.threads.JMeterContextService;
import org.apache.jmeter.testelement.AbstractTestElement;

/**
 * JMeter listener that receives completed samples and forms interval-level metrics.
 */
public class ElasticMetricsListener extends AbstractTestElement
        implements SampleListener, TestStateListener, Serializable {

    private static final long serialVersionUID = 1L;

    public static final String CONTROL_INTERVAL_SECONDS = "LoadGuardMetricsListener.controlIntervalSeconds";
    public static final String WARMUP_SECONDS = "LoadGuardMetricsListener.warmupSeconds";
    public static final String RESPONSE_SLO_MS = "LoadGuardMetricsListener.responseSloMs";
    public static final String ERROR_SLO_PERCENT = "LoadGuardMetricsListener.errorSloPercent";
    public static final String INCREASE_PERCENT = "LoadGuardMetricsListener.increasePercent";
    public static final String DECREASE_PERCENT = "LoadGuardMetricsListener.decreasePercent";
    public static final String HOLD_MARGIN_PERCENT = "LoadGuardMetricsListener.holdMarginPercent";
    public static final String WRITE_DECISION_CSV = "LoadGuardMetricsListener.writeDecisionCsv";
    public static final String DECISION_CSV_PATH = "LoadGuardMetricsListener.decisionCsvPath";
    public static final String VERBOSE = "LoadGuardMetricsListener.verbose";

    private transient SampleWindow window;

    @Override
    public void testStarted() {
        configureController();
        window = new SampleWindow();
    }

    @Override
    public void testStarted(String host) {
        testStarted();
    }

    @Override
    public void testEnded() {
        window = null;
    }

    @Override
    public void testEnded(String host) {
        testEnded();
    }

    @Override
    public void sampleOccurred(SampleEvent event) {
        if (event == null || event.getResult() == null) {
            return;
        }

        if (window == null) {
            window = new SampleWindow();
        }

        SampleResult result = event.getResult();
        window.add(result.getTime(), result.isSuccessful());

        long now = System.currentTimeMillis();
        long intervalMs = LoadGuardController.getInstance().getControlIntervalSeconds() * 1000L;

        if (window.isDue(now, intervalMs)) {
            int activeThreads = Math.max(1, JMeterContextService.getNumberOfThreads());
            SampleWindow.WindowMetrics metrics = window.closeAndReset(now, activeThreads);
            LoadGuardController.getInstance().decide(metrics);
        }
    }

    @Override
    public void sampleStarted(SampleEvent event) {
        // Not used.
    }

    @Override
    public void sampleStopped(SampleEvent event) {
        // Not used.
    }

    private void configureController() {
        int interval = getPropertyAsInt(CONTROL_INTERVAL_SECONDS, 5);
        int warmup = getPropertyAsInt(WARMUP_SECONDS, 15);
        long responseSlo = getPropertyAsLong(RESPONSE_SLO_MS, 1000L);
        double errorSlo = getPropertyAsDouble(ERROR_SLO_PERCENT, 5.0);
        double increase = getPropertyAsDouble(INCREASE_PERCENT, 20.0);
        double decrease = getPropertyAsDouble(DECREASE_PERCENT, 30.0);
        double holdMargin = getPropertyAsDouble(HOLD_MARGIN_PERCENT, 30.0);
        boolean writeCsv = getPropertyAsBoolean(WRITE_DECISION_CSV, true);
        String csvPath = getPropertyAsString(DECISION_CSV_PATH, "loadguard-decisions.csv");
        boolean verbose = getPropertyAsBoolean(VERBOSE, false);

        LoadGuardController.getInstance().configureListener(
                interval, warmup, responseSlo, errorSlo, increase, decrease,
                holdMargin, writeCsv, csvPath, verbose);
    }
}
