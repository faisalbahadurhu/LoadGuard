package org.loadguard.elastic;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.visualizers.gui.AbstractListenerGui;

/**
 * GUI component for LoadGuard Metrics Listener.
 */
public class ElasticMetricsListenerGui extends AbstractListenerGui {

    private static final long serialVersionUID = 1L;

    private JTextField intervalField;
    private JTextField warmupField;
    private JTextField responseSloField;
    private JTextField errorSloField;
    private JTextField increaseField;
    private JTextField decreaseField;
    private JTextField holdMarginField;
    private JCheckBox writeCsvCheckBox;
    private JTextField csvPathField;
    private JCheckBox verboseCheckBox;

    public ElasticMetricsListenerGui() {
        init();
    }

    @Override
    public String getStaticLabel() {
        return "LoadGuard Metrics Listener";
    }

    @Override
    public String getLabelResource() {
        return null;
    }

    @Override
    public TestElement createTestElement() {
        ElasticMetricsListener listener = new ElasticMetricsListener();
        modifyTestElement(listener);
        return listener;
    }

    @Override
    public void modifyTestElement(TestElement element) {
        configureTestElement(element);
        element.setProperty(ElasticMetricsListener.CONTROL_INTERVAL_SECONDS, parseInt(intervalField.getText(), 5));
        element.setProperty(ElasticMetricsListener.WARMUP_SECONDS, parseInt(warmupField.getText(), 15));
        element.setProperty(ElasticMetricsListener.RESPONSE_SLO_MS, parseLong(responseSloField.getText(), 1000L));
        element.setProperty(ElasticMetricsListener.ERROR_SLO_PERCENT, parseDouble(errorSloField.getText(), 5.0));
        element.setProperty(ElasticMetricsListener.INCREASE_PERCENT, parseDouble(increaseField.getText(), 20.0));
        element.setProperty(ElasticMetricsListener.DECREASE_PERCENT, parseDouble(decreaseField.getText(), 30.0));
        element.setProperty(ElasticMetricsListener.HOLD_MARGIN_PERCENT, parseDouble(holdMarginField.getText(), 30.0));
        element.setProperty(ElasticMetricsListener.WRITE_DECISION_CSV, writeCsvCheckBox.isSelected());
        element.setProperty(ElasticMetricsListener.DECISION_CSV_PATH, csvPathField.getText());
        element.setProperty(ElasticMetricsListener.VERBOSE, verboseCheckBox.isSelected());
    }

    @Override
    public void configure(TestElement element) {
        super.configure(element);
        intervalField.setText(String.valueOf(element.getPropertyAsInt(ElasticMetricsListener.CONTROL_INTERVAL_SECONDS, 5)));
        warmupField.setText(String.valueOf(element.getPropertyAsInt(ElasticMetricsListener.WARMUP_SECONDS, 15)));
        responseSloField.setText(String.valueOf(element.getPropertyAsLong(ElasticMetricsListener.RESPONSE_SLO_MS, 1000L)));
        errorSloField.setText(String.valueOf(element.getPropertyAsDouble(ElasticMetricsListener.ERROR_SLO_PERCENT, 5.0)));
        increaseField.setText(String.valueOf(element.getPropertyAsDouble(ElasticMetricsListener.INCREASE_PERCENT, 20.0)));
        decreaseField.setText(String.valueOf(element.getPropertyAsDouble(ElasticMetricsListener.DECREASE_PERCENT, 30.0)));
        holdMarginField.setText(String.valueOf(element.getPropertyAsDouble(ElasticMetricsListener.HOLD_MARGIN_PERCENT, 30.0)));
        writeCsvCheckBox.setSelected(element.getPropertyAsBoolean(ElasticMetricsListener.WRITE_DECISION_CSV, true));
        csvPathField.setText(element.getPropertyAsString(ElasticMetricsListener.DECISION_CSV_PATH, "loadguard-decisions.csv"));
        verboseCheckBox.setSelected(element.getPropertyAsBoolean(ElasticMetricsListener.VERBOSE, false));
    }

    @Override
    public void clearGui() {
        super.clearGui();
        intervalField.setText("5");
        warmupField.setText("15");
        responseSloField.setText("1000");
        errorSloField.setText("5");
        increaseField.setText("20");
        decreaseField.setText("30");
        holdMarginField.setText("30");
        writeCsvCheckBox.setSelected(true);
        csvPathField.setText("loadguard-decisions.csv");
        verboseCheckBox.setSelected(false);
    }

    private void init() {
        setLayout(new BorderLayout(0, 5));
        setBorder(makeBorder());
        add(getNamePanel(), BorderLayout.NORTH);

        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));

        intervalField = new JTextField("5");
        warmupField = new JTextField("15");
        responseSloField = new JTextField("1000");
        errorSloField = new JTextField("5");
        increaseField = new JTextField("20");
        decreaseField = new JTextField("30");
        holdMarginField = new JTextField("30");
        writeCsvCheckBox = new JCheckBox("Write decision CSV", true);
        csvPathField = new JTextField("loadguard-decisions.csv");
        verboseCheckBox = new JCheckBox("Verbose logging", false);

        panel.add(new JLabel("Control interval seconds"));
        panel.add(intervalField);
        panel.add(new JLabel("Warm-up seconds"));
        panel.add(warmupField);
        panel.add(new JLabel("p95 response-time SLO ms"));
        panel.add(responseSloField);
        panel.add(new JLabel("Error-rate SLO percent"));
        panel.add(errorSloField);
        panel.add(new JLabel("Increase percent"));
        panel.add(increaseField);
        panel.add(new JLabel("Decrease percent"));
        panel.add(decreaseField);
        panel.add(new JLabel("HOLD margin percent"));
        panel.add(holdMarginField);
        panel.add(new JLabel("Write decision CSV"));
        panel.add(writeCsvCheckBox);
        panel.add(new JLabel("Decision CSV path"));
        panel.add(csvPathField);
        panel.add(new JLabel("Verbose logging"));
        panel.add(verboseCheckBox);

        add(panel, BorderLayout.CENTER);
    }

    private static int parseInt(String text, int defaultValue) {
        try { return Integer.parseInt(text.trim()); } catch (Exception ex) { return defaultValue; }
    }

    private static long parseLong(String text, long defaultValue) {
        try { return Long.parseLong(text.trim()); } catch (Exception ex) { return defaultValue; }
    }

    private static double parseDouble(String text, double defaultValue) {
        try { return Double.parseDouble(text.trim()); } catch (Exception ex) { return defaultValue; }
    }
}
