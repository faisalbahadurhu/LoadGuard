package org.loadguard.elastic;

import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Shared controller used by the LoadGuard Timer and Metrics Listener.
 * The current version implements an SLO-aware closed-loop controller:
 * WARMUP -> INCREASE -> HOLD -> DECREASE.
 */
public final class LoadGuardController {

    private static final Logger LOG = LoggerFactory.getLogger(LoadGuardController.class);
    private static final LoadGuardController INSTANCE = new LoadGuardController();

    private double targetRps = 5.0;
    private double minRps = 1.0;
    private double maxRps = 50.0;

    private int controlIntervalSeconds = 5;
    private int warmupSeconds = 15;

    private long responseSloMs = 1000;
    private double errorSloPercent = 5.0;

    private double increasePercent = 20.0;
    private double decreasePercent = 30.0;
    private double holdMarginPercent = 30.0;

    private boolean verboseLogging = false;
    private boolean writeDecisionCsv = true;
    private String decisionCsvPath = "loadguard-decisions.csv";

    private long testStartMs = 0L;
    private long timerDelayMs = 0L;
    private String lastAction = "INIT";

    private LoadGuardCsvWriter csvWriter;

    private LoadGuardController() {}

    public static LoadGuardController getInstance() {
        return INSTANCE;
    }

    public synchronized void configureTimer(double initialRps, double minRps, double maxRps, boolean verboseLogging) {
        this.targetRps = positiveOrDefault(initialRps, 5.0);
        this.minRps = positiveOrDefault(minRps, 1.0);
        this.maxRps = positiveOrDefault(maxRps, 50.0);
        if (this.minRps > this.maxRps) {
            double tmp = this.minRps;
            this.minRps = this.maxRps;
            this.maxRps = tmp;
        }
        this.targetRps = clamp(this.targetRps, this.minRps, this.maxRps);
        this.verboseLogging = verboseLogging;
    }

    public synchronized void configureListener(
            int controlIntervalSeconds,
            int warmupSeconds,
            long responseSloMs,
            double errorSloPercent,
            double increasePercent,
            double decreasePercent,
            double holdMarginPercent,
            boolean writeDecisionCsv,
            String decisionCsvPath,
            boolean verboseLogging) {

        this.controlIntervalSeconds = Math.max(1, controlIntervalSeconds);
        this.warmupSeconds = Math.max(0, warmupSeconds);
        this.responseSloMs = Math.max(1, responseSloMs);
        this.errorSloPercent = Math.max(0.0001, errorSloPercent);
        this.increasePercent = Math.max(0.0, increasePercent);
        this.decreasePercent = Math.max(0.0, decreasePercent);
        this.holdMarginPercent = clamp(holdMarginPercent, 0.0, 99.0);
        this.writeDecisionCsv = writeDecisionCsv;
        this.decisionCsvPath = (decisionCsvPath == null || decisionCsvPath.trim().isEmpty())
                ? "loadguard-decisions.csv" : decisionCsvPath.trim();
        this.verboseLogging = this.verboseLogging || verboseLogging;
    }

    public synchronized void testStarted() {
        testStartMs = System.currentTimeMillis();
        lastAction = "INIT";

        if (writeDecisionCsv) {
            csvWriter = new LoadGuardCsvWriter(decisionCsvPath);
            csvWriter.open();
        }

        LOG.info("[LoadGuard v1.2] started. targetRps={}, minRps={}, maxRps={}, interval={}s, warmup={}s, csv={}",
                format(targetRps), format(minRps), format(maxRps), controlIntervalSeconds, warmupSeconds, decisionCsvPath);
    }

    public synchronized void testEnded() {
        if (csvWriter != null) {
            csvWriter.close();
            csvWriter = null;
        }
        LOG.info("[LoadGuard v1.2] stopped.");
    }

    public synchronized Decision decide(SampleWindow.WindowMetrics m) {
        long now = System.currentTimeMillis();
        double elapsedSeconds = testStartMs > 0 ? (now - testStartMs) / 1000.0 : 0.0;

        double oldTarget = targetRps;
        String controlState;
        String riskZone;
        String action;

        double responseUsage = (m.p95ResponseMs * 100.0) / responseSloMs;
        double errorUsage = (m.errorRatePercent * 100.0) / errorSloPercent;
        double sloUsage = Math.max(responseUsage, errorUsage);

        boolean inWarmup = elapsedSeconds < warmupSeconds;

        if (inWarmup) {
            controlState = "WARMUP";
            riskZone = "WARMUP_ZONE";
            action = "WARMUP";
            targetRps = oldTarget;
        } else if (sloUsage > 100.0) {
            controlState = "VIOLATION";
            riskZone = "VIOLATION_ZONE";
            action = "DECREASE";
            targetRps = Math.max(minRps, oldTarget * (1.0 - (decreasePercent / 100.0)));
        } else if (sloUsage >= (100.0 - holdMarginPercent)) {
            controlState = "WARNING";
            riskZone = "HOLD_ZONE";
            action = "HOLD";
            targetRps = oldTarget;
        } else {
            controlState = "OK";
            riskZone = "SAFE_ZONE";
            action = "INCREASE";
            targetRps = Math.min(maxRps, oldTarget * (1.0 + (increasePercent / 100.0)));
        }

        targetRps = clamp(targetRps, minRps, maxRps);
        lastAction = action;

        Decision d = new Decision();
        d.elapsedSeconds = elapsedSeconds;
        d.epochMs = now;
        d.windowSeconds = m.windowSeconds;
        d.oldTargetRps = oldTarget;
        d.newTargetRps = targetRps;
        d.targetRps = targetRps;
        d.observedTps = m.observedTps;
        d.activeThreads = m.activeThreads;
        d.samples = m.samples;
        d.avgResponseMs = m.avgResponseMs;
        d.p95ResponseMs = m.p95ResponseMs;
        d.p99ResponseMs = m.p99ResponseMs;
        d.minResponseMs = m.minResponseMs;
        d.maxResponseMs = m.maxResponseMs;
        d.errorCount = m.errorCount;
        d.errorRatePercent = m.errorRatePercent;
        d.responseSloMs = responseSloMs;
        d.errorSloPercent = errorSloPercent;
        d.sloUsagePercent = sloUsage;
        d.controlState = controlState;
        d.riskZone = riskZone;
        d.action = action;
        d.timerDelayMs = timerDelayMs;

        if (csvWriter != null) {
            csvWriter.write(d);
        }

        if (verboseLogging) {
            LOG.info("[LoadGuard v1.2] {}", d.toLogLine());
        }

        return d;
    }

    public synchronized double getTargetRps() {
        return Math.max(minRps, Math.min(maxRps, targetRps));
    }

    public synchronized int getControlIntervalSeconds() {
        return controlIntervalSeconds;
    }

    public synchronized void setTimerDelayMs(long timerDelayMs) {
        this.timerDelayMs = Math.max(0L, timerDelayMs);
    }

    public synchronized long getTimerDelayMs() {
        return timerDelayMs;
    }

    public synchronized String getLastAction() {
        return lastAction;
    }

    private static double positiveOrDefault(double value, double defaultValue) {
        return value > 0.0 ? value : defaultValue;
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    static String format(double value) {
        return String.format(Locale.US, "%.3f", value);
    }

    public static final class Decision {
        public double elapsedSeconds;
        public long epochMs;
        public double windowSeconds;
        public double oldTargetRps;
        public double newTargetRps;
        public double targetRps;
        public double observedTps;
        public int activeThreads;
        public int samples;
        public double avgResponseMs;
        public long p95ResponseMs;
        public long p99ResponseMs;
        public long minResponseMs;
        public long maxResponseMs;
        public int errorCount;
        public double errorRatePercent;
        public long responseSloMs;
        public double errorSloPercent;
        public double sloUsagePercent;
        public String controlState;
        public String riskZone;
        public String action;
        public long timerDelayMs;

        public String toCsvLine() {
            return String.format(Locale.US,
                    "%.3f,%d,%.3f,%.3f,%.3f,%.3f,%.3f,%d,%d,%.3f,%d,%d,%d,%d,%d,%.3f,%d,%.3f,%.3f,%s,%s,%s,%d",
                    elapsedSeconds, epochMs, windowSeconds, oldTargetRps, newTargetRps, targetRps,
                    observedTps, activeThreads, samples, avgResponseMs, p95ResponseMs, p99ResponseMs,
                    minResponseMs, maxResponseMs, errorCount, errorRatePercent, responseSloMs,
                    errorSloPercent, sloUsagePercent, controlState, riskZone, action, timerDelayMs);
        }

        public String toLogLine() {
            return String.format(Locale.US,
                    "elapsed=%.3fs samples=%d observedTps=%.3f p95=%dms error=%.3f%% sloUsage=%.3f%% state=%s zone=%s action=%s target %.3f -> %.3f",
                    elapsedSeconds, samples, observedTps, p95ResponseMs, errorRatePercent,
                    sloUsagePercent, controlState, riskZone, action, oldTargetRps, newTargetRps);
        }
    }
}
