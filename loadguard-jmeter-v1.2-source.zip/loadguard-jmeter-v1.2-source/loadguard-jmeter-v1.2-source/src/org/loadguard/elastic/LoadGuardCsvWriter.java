package org.loadguard.elastic;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * CSV output writer for interval-level LoadGuard controller decisions.
 */
public final class LoadGuardCsvWriter {

    private static final Logger LOG = LoggerFactory.getLogger(LoadGuardCsvWriter.class);

    private final String pathText;
    private BufferedWriter writer;

    public LoadGuardCsvWriter(String pathText) {
        this.pathText = pathText;
    }

    public synchronized void open() {
        try {
            Path path = Paths.get(pathText);
            Path parent = path.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);

            writer.write(header());
            writer.newLine();
            writer.flush();

            LOG.info("[LoadGuard v1.2] decision CSV opened: {}", path.toAbsolutePath());
        } catch (IOException ex) {
            LOG.error("[LoadGuard v1.2] failed to open decision CSV: {}", pathText, ex);
            writer = null;
        }
    }

    public synchronized void write(LoadGuardController.Decision decision) {
        if (writer == null || decision == null) {
            return;
        }

        try {
            writer.write(decision.toCsvLine());
            writer.newLine();
            writer.flush();
        } catch (IOException ex) {
            LOG.error("[LoadGuard v1.2] failed to write decision CSV row", ex);
        }
    }

    public synchronized void close() {
        if (writer == null) {
            return;
        }

        try {
            writer.flush();
            writer.close();
        } catch (IOException ex) {
            LOG.warn("[LoadGuard v1.2] error while closing CSV writer", ex);
        } finally {
            writer = null;
        }
    }

    private String header() {
        return "elapsed_s,epoch_ms,window_seconds,old_target_rps,new_target_rps,target_rps,"
                + "observed_tps,active_threads,samples,avg_response_ms,p95_response_ms,p99_response_ms,"
                + "min_response_ms,max_response_ms,error_count,error_rate_percent,response_slo_ms,"
                + "error_slo_percent,slo_usage_percent,control_state,risk_zone,action,timer_delay_ms";
    }
}
