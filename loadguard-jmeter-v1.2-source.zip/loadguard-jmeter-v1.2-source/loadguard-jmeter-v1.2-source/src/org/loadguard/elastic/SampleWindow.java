package org.loadguard.elastic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Holds samples for one monitoring interval and computes interval metrics.
 */
public final class SampleWindow {

    private final List<Long> responseTimes = new ArrayList<>();
    private int errorCount = 0;
    private long windowStartMs = System.currentTimeMillis();

    public synchronized void add(long responseTimeMs, boolean success) {
        responseTimes.add(Math.max(0L, responseTimeMs));
        if (!success) {
            errorCount++;
        }
    }

    public synchronized boolean isDue(long nowMs, long intervalMs) {
        return !responseTimes.isEmpty() && (nowMs - windowStartMs) >= intervalMs;
    }

    public synchronized WindowMetrics closeAndReset(long nowMs, int activeThreads) {
        WindowMetrics m = compute(nowMs, activeThreads);
        responseTimes.clear();
        errorCount = 0;
        windowStartMs = nowMs;
        return m;
    }

    private WindowMetrics compute(long nowMs, int activeThreads) {
        WindowMetrics m = new WindowMetrics();
        int n = responseTimes.size();
        double seconds = Math.max(0.001, (nowMs - windowStartMs) / 1000.0);

        m.windowSeconds = seconds;
        m.activeThreads = Math.max(1, activeThreads);
        m.samples = n;
        m.errorCount = errorCount;
        m.errorRatePercent = n > 0 ? (errorCount * 100.0) / n : 0.0;
        m.observedTps = n / seconds;

        if (n == 0) {
            m.avgResponseMs = 0.0;
            m.p95ResponseMs = 0L;
            m.p99ResponseMs = 0L;
            m.minResponseMs = 0L;
            m.maxResponseMs = 0L;
            return m;
        }

        List<Long> sorted = new ArrayList<>(responseTimes);
        Collections.sort(sorted);

        long sum = 0L;
        for (Long value : sorted) {
            sum += value;
        }

        m.avgResponseMs = sum / (double) n;
        m.minResponseMs = sorted.get(0);
        m.maxResponseMs = sorted.get(n - 1);
        m.p95ResponseMs = percentile(sorted, 95.0);
        m.p99ResponseMs = percentile(sorted, 99.0);
        return m;
    }

    private static long percentile(List<Long> sorted, double percentile) {
        if (sorted.isEmpty()) {
            return 0L;
        }
        int n = sorted.size();
        int index = (int) Math.ceil((percentile / 100.0) * n) - 1;
        index = Math.max(0, Math.min(index, n - 1));
        return sorted.get(index);
    }

    public static final class WindowMetrics {
        public double windowSeconds;
        public double observedTps;
        public int activeThreads;
        public int samples;
        public double avgResponseMs;
        public long p95ResponseMs;
        public long p99ResponseMs;
        public long minResponseMs;
        public long maxResponseMs;
        public int errorCount;
        public double errorRatePercent;
    }
}
